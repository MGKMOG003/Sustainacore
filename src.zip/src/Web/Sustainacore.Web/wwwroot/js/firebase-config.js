﻿// Your 3.1 config (safe to expose in web app; private keys are not here)
export const firebaseConfig = {
    apiKey: "AIzaSyCXjHkXlfbLAcLXnQnQBllzU5T2NffxYnA",
    authDomain: "sustainacore-69e3e.firebaseapp.com",
    databaseURL: "https://sustainacore-69e3e-default-rtdb.firebaseio.com",
    projectId: "sustainacore-69e3e",
    storageBucket: "sustainacore-69e3e.firebasestorage.app",
    messagingSenderId: "659869831545",
    appId: "1:659869831545:web:b89abe62fd3aef3a4e9fa8",
    measurementId: "G-YVBSM0VMQE"
};

