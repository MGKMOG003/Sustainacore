﻿namespace Sustainacore.Contracts;

public class Class1
{

}
