# Sustainacore.Domain
DDD aggregates, value objects, domain services, domain events.
No EF Core or infrastructure code here.
