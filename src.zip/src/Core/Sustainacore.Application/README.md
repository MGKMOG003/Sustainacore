# Sustainacore.Application
CQRS commands/queries/handlers, validators, policies, pipelines.
Depends only on Domain + SharedKernel via abstractions.
