﻿namespace Sustainacore.SharedKernel;

public class Class1
{

}
