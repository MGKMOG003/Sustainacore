[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "Sustainacore.Mobile")]
[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "Sustainacore.Mobile.Pages")]
