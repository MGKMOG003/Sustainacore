﻿namespace Sustainacore.Firebase;

public class Class1
{

}
