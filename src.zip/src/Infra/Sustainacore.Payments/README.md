# Sustainacore.Payments
Adapters for PayFast/PayPal/EFT; webhook validators.
