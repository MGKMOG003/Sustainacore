﻿namespace Sustainacore.Payments;

public class Class1
{

}
