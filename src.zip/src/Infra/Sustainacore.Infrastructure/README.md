# Sustainacore.Infrastructure
EF Core mappings, repositories, UoW, Outbox dispatcher, adapters.
References Firebase and Payments adapter libraries.
