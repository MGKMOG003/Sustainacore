﻿namespace Sustainacore.Observability;

public class Class1
{

}
